export default function StatusBar() {
  return <></>
}

